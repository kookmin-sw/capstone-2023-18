﻿// Copyright (c) 2022 Justin Couch / JustInvoke
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PowerslideKartPhysics
{
    // Class for vall collision detection based on checking for the wall component (basically acts as a tag)
    public class Wall : MonoBehaviour
    {
    }
}
